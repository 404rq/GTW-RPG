col11  = createColCircle(3159, -1967, 10, 10)
gate11 = createObject(980, 3159, -1962.8, 12.5, 0, 0, 90)                             
function openGate11(player)
    if isElement(player) and ( getElementData(player, "Group" ) == "ACRP" or getElementData(player, "Group" ) == "SWAT" ) then
        moveObject(gate11, 3000, 3159, -1947.8, 12.5) 
	end
end  
addEventHandler("onColShapeHit", col11, openGate11)
 
function closeGate11(player)
    if isElement(player) and ( getElementData(player, "Group" ) == "ACRP" or getElementData(player, "Group" ) == "SWAT" ) then
        moveObject(gate11, 3000, 3159, -1962.8, 12.5) 
	end
end
addEventHandler("onColShapeLeave", col11, closeGate11)

