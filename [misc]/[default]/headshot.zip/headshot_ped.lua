addEvent "onClientPedHeadshot"

function pedHeadShot(attacker, weapon, bodypart, loss)
	if bodypart == 9 and not getElementData(source, "robLoc") then
		local result = triggerEvent("onClientPedHeadshot", source, attacker, weapon, loss)
		triggerServerEvent("onPedDamage", localPlayer, source, attacker, weapon, bodypart)
	end
end
addEventHandler("onClientPedDamage", root, pedHeadShot)
