addEvent "onPlayerHeadshot"

function playerHeadShot(attacker, weapon, bodypart, loss)
	if bodypart == 9 then
		local result = triggerEvent("onPlayerHeadshot", source, attacker, weapon, loss)
		if result == true and getPedArmor(source) < 40 then
			killPed(source, attacker, weapon, bodypart)
		end
	end
end
addEventHandler("onPlayerDamage", root, playerHeadShot)

function pedHeadShot(ped, attacker, weapon, bodypart)
	if ped and isElement(ped) then
		killPed(ped, attacker, weapon, bodypart)
	end
end
addEvent("onPedDamage", true)
addEventHandler("onPedDamage", root, pedHeadShot) 