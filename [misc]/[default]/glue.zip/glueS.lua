function gluePlayer(slot, vehicle, x, y, z, rotX, rotY, rotZ)
	--if getVehicleType( vehicle ) == "Boat" then
	obj = client
	if getPedOccupiedVehicle(obj) then obj = getPedOccupiedVehicle(obj) end
	attachElements(obj, vehicle, x, y, z, rotX, rotY, rotZ)
	setPedWeaponSlot(client, slot)
	exports.GTWtopbar:dm( "You have glued to this vehicle, use /unglue to leave it", client, 0, 255, 0 )
	--end
end
addEvent("gluePlayer",true)
addEventHandler("gluePlayer",getRootElement(),gluePlayer)

function ungluePlayer()
	detachElements(source)
	exports.GTWtopbar:dm( "You have been unglued from the vehicle", client, 0, 255, 0 )
end
addEvent("ungluePlayer",true)
addEventHandler("ungluePlayer",getRootElement(),ungluePlayer)