function gluePlayer(slot, vehicle, x, y, z, rotX, rotY, rotZ)
	--if getVehicleType( vehicle ) == "Boat" then
	local object_item = client
	if getPedOccupiedVehicle(object_item) then object_item = getPedOccupiedVehicle(object_item) end
	attachElements(object_item, vehicle, x, y, z, rotX, rotY, rotZ)
	setPedWeaponSlot(client, slot)
	exports.GTWtopbar:dm( "You have glued to this vehicle, use /unglue to leave it", client, 0, 255, 0 )
	--end
end
addEvent("gluePlayer",true)
addEventHandler("gluePlayer",getRootElement(),gluePlayer)

function ungluePlayer()
	detachElements(source)
	exports.GTWtopbar:dm( "You have been unglued from the vehicle", client, 0, 255, 0 )
end
addEvent("ungluePlayer",true)
addEventHandler("ungluePlayer",getRootElement(),ungluePlayer)